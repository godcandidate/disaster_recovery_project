const AWS = require('aws-sdk');

exports.handler = async (event) => {
    const autoscaling = new AWS.AutoScaling();
    const sns = new AWS.SNS();
    
    // Get environment variables
    const asgName = process.env.AUTO_SCALING_GROUP_NAME;
    const desiredCapacity = process.env.DESIRED_CAPACITY;
    const snsTopicArn = process.env.SNS_TOPIC_ARN;
    
    console.log('Updating Auto Scaling Group ' + asgName + ' to desired capacity ' + desiredCapacity);
    
    try {
        // Update the Auto Scaling Group
        const asgResult = await autoscaling.updateAutoScalingGroup({
            AutoScalingGroupName: asgName,
            DesiredCapacity: parseInt(desiredCapacity),
            MinSize: parseInt(desiredCapacity)
        }).promise();
        
        console.log('Auto Scaling Group updated successfully');
        
        // Send success notification
        if (snsTopicArn) {
            await sns.publish({
                TopicArn: snsTopicArn,
                Subject: 'DR Failover Success',
                Message: 'Disaster Recovery failover completed successfully!\n\nAuto Scaling Group ' + asgName + ' has been scaled to ' + desiredCapacity + ' instance(s).\n\nTime: ' + new Date().toISOString() + '\n\nThis is an automated message from your DR infrastructure.'
            }).promise();
            console.log('Success notification sent');
        }
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'DR failover initiated successfully',
                asgName: asgName,
                desiredCapacity: desiredCapacity
            })
        };
    } catch (error) {
        console.error('Error updating Auto Scaling Group:', error);
        
        // Send failure notification
        if (snsTopicArn) {
            try {
                await sns.publish({
                    TopicArn: snsTopicArn,
                    Subject: 'DR Failover Failed',
                    Message: 'Disaster Recovery failover failed!\n\nError: ' + error.message + '\n\nTime: ' + new Date().toISOString() + '\n\nPlease check the CloudWatch logs for more details.\n\nThis is an automated message from your DR infrastructure.'
                }).promise();
                console.log('Failure notification sent');
            } catch (snsError) {
                console.error('Error sending SNS notification:', snsError);
            }
        }
        
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Error initiating DR failover',
                error: error.message
            })
        };
    }
};
