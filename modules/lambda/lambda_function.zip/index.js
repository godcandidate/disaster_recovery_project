const AWS = require('aws-sdk');

exports.handler = async (event) => {
    const autoscaling = new AWS.AutoScaling();
    
    // Get environment variables
    const asgName = process.env.AUTO_SCALING_GROUP_NAME;
    const desiredCapacity = process.env.DESIRED_CAPACITY;
    
    console.log('Updating Auto Scaling Group ' + asgName + ' to desired capacity ' + desiredCapacity);
    
    try {
        // Update the Auto Scaling Group
        const asgResult = await autoscaling.updateAutoScalingGroup({
            AutoScalingGroupName: asgName,
            DesiredCapacity: parseInt(desiredCapacity),
            MinSize: parseInt(desiredCapacity)
        }).promise();
        
        console.log('Auto Scaling Group updated successfully');
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'DR failover initiated successfully',
                asgName: asgName,
                desiredCapacity: desiredCapacity
            })
        };
    } catch (error) {
        console.error('Error updating Auto Scaling Group:', error);
        
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Error initiating DR failover',
                error: error.message
            })
        };
    }
};
